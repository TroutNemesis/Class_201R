# Awesome, you've just made a new workspace!
Workspaces are fantastic for organizing your work. This new workspace, which lives inside the 'Workspaces' folder of your home
directory, is a place where you can store all relevant and related files to a particular project. For example, if you
are working on multiple projects, its nice to have them separated as follows:
-|home dir
   -|Workspaces
    -| Project 1
    -| Project 2
    -| Project 3

Workspaces help keep your projects organized. You can create any number of workspaces. There are no limits.

Note: A workspace folder is just a regular folder so you can create any number of files and folders inside it.

As you move back and forth between your workspaces, Koding will remember everything about each workspace. This includes things
like IDE settings, files open, Terminals open, etc.

Enjoy and Happy Koding!